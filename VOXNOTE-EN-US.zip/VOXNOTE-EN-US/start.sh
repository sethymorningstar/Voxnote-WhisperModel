#!/data/data/com.termux/files/usr/bin/bash

clear

blue(){ echo -e "\e[5;34m$1\e[0m"; }


blue "   __ __   ___   __ __  ____    ___   ______    ___ "
sleep 0.3
blue "  |  |  | /   \ |  |  ||    \  /   \ |      |  /  _]"
sleep 0.2
blue "  |  |  ||     ||  |  ||  _  ||     ||      | /  [_ "
sleep 0.2
blue "  |  |  ||  O  ||_   _||  |  ||  O  ||_|  |_||    _]"
sleep 0.2
blue "  |  :  ||     ||     ||  |  ||     |  |  |  |   [_ "
sleep 0.2
blue "   \   / |     ||  |  ||  |  ||     |  |  |  |     |"
sleep 0.1
blue "    \_/   \___/ |__|__||__|__| \___/   |__|  |_____|"
echo "                🎧  Initializing  🎧"
echo ""
# Real-time spinning "X" animation
spinner=('×' 'X' '✶' '✹' '×' '✹' 'x' 'X')
for i in {1..3}; do
  for j in "${spinner[@]}"; do
    echo -ne "\r                    V O $j N O T E"
    sleep 0.1
  done
done

echo -ne "\r                    V O ̶X̶ N O T E\n"
sleep 0.4
echo ""
# Animated Menu
echo -e "\e[96m"
echo "   ╭──────────────────────────────────────────────╮"
sleep 0.1
echo "   │       🧠 VoXnote Transcriber [Offline]       │"
sleep 0.1
echo "   ├──────────────────────────────────────────────┤"
sleep 0.1
echo "   │ 1. 🎤 Transcribe YouTube video audio         │"
sleep 0.1
echo "   │ 2. 🎤 Transcribe audio from VOXNOTE folder   │"
sleep 0.1
echo "   │ 3. 📄 Auto-subtitle videos                   │"
echo "   ╰──────────────────────────────────────────────╯"
echo -e "\e[0m"
echo "  1- Transcribes and exports subtitles using YouTube links (Online)"
echo "  2- Transcribes and exports subtitles from local files (Offline)"
echo "  2.5- First, you must put your audio/video files inside the VOXNOTE/Manual Transcription folder on your device"
echo "  3- Merges the exported subtitle with the original video inside VOXNOTE/Manual Transcription"
echo ""
echo ""
read -p "👉 Choose an option (1-2-3): " opcao

if [[ "$opcao" == "1" ]]; then
  clear
  echo -e "\e[92m🔧 Starting...\e[0m"
  sleep 0.5
elif [[ "$opcao" == "2" ]]; then
  echo -e "\e[91m ○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○○●●● \e[0m"
  bash $HOME/VOXNOTE/scripts/transcrever2.sh
elif [[ "$opcao" == "3" ]]; then
  bash $HOME/VOXNOTE/scripts/legendar.sh
else
  echo -e "\e[91mInvalid option. Try again!\e[0m"
  sleep 1
  bash $HOME/VOXNOTE/start.sh
fi

# Call main script with the YouTube video URL as argument
read -p "🔗 Paste the YouTube video link: " VIDEO_URL
echo ""
bash $HOME/VOXNOTE/scripts/transcrever.sh "$VIDEO_URL"
