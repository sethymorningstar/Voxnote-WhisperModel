#!/data/data/com.termux/files/usr/bin/bash

echo "PLEASE GRANT ACCESS TO INTERNAL STORAGE FOR THE SCRIPT TO RUN CORRECTLY!"
sleep 3

termux-setup-storage                                  
# ╔═════════════════════════════════════════════╗     # ║     🧠 VoXnote Automatic Installer 💽       ║
# ╚═════════════════════════════════════════════╝                                                           
loading_animation() {
  echo -ne "\n🔄 Setting up environment"
  for i in {1..5}; do
    echo -ne "."
    sleep 0.4
  done
  echo -e " ✅\n"
}

# 🛠️ Check and install dependencies
check_dep() {
  local PKG_NAME="$1"
  if ! command -v "$PKG_NAME" >/dev/null 2>&1; then
    echo -e "📦 Installing dependency: \033[1;34m$PKG_NAME\033[0m..."
    pkg install -y "$PKG_NAME" >/dev/null 2>&1
    echo "✅ $PKG_NAME successfully installed!"
  else
    echo "✅ $PKG_NAME is already installed!"
  fi
}

# 🎬 Initial interface
echo -e "\033[1;32m"
echo "╔════════════════════════════════════════════════════════╗"
echo "║              🚀 VOXNOTE INSTALLER!                     ║"
echo "║        Full automation for Termux Widget support       ║"
echo "╚════════════════════════════════════════════════════════╝"
echo -e "\033[0m"

loading_animation

# 🔍 Check dependencies
echo -e "🔧 Checking and installing dependencies...\n"
check_dep yt-dlp
check_dep ffmpeg
check_dep termux-api
echo -e "⚠️ The Termux API (APK format) is available on F-DROID. For more info, read the README.txt file ⚠️"
sleep 1.3
pkg install curl -y
mv $HOME/VOXNOTE-EN-US $HOME/VOXNOTE
# Downloading Whisper.cpp models
echo -e "\n🌐 Escolha o modelo Whisper que deseja usar:"
echo "1) 🐣 small (Default--488MB)"
echo "2) 🧠 medium (~1GB)"
echo "3) ⚡️ base (~148MB)"
echo "3) 🚀 large-v3 (~3GB)"
read -p "Digite o número do modelo desejado: " model_choice

MODEL_URL=""
MODEL_NAME=""

case "$model_choice" in
  1)
    MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin"
    MODEL_NAME="ggml-small.bin"
    ;;
  2)
    MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin"
    MODEL_NAME="ggml-medium.bin"
    ;;
  3)
    MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
    MODEL_NAME="ggml-base.bin"
   ;;
  4)
    MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3.bin"
    MODEL_NAME="ggml-large-v3.bin"
    ;;
  *)
    echo "❌ Opção inválida! Usando modelo small por padrão."
    MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin"
    MODEL_NAME="ggml-small.bin"
    ;;
esac

MODEL_DIR="$HOME/VOXNOTE/models"
mkdir -p "$MODEL_DIR"

echo -e "\n📥 Baixando o modelo: $MODEL_NAME..."
curl -L -o "$MODEL_DIR/$MODEL_NAME" "$MODEL_URL"

if [ $? -eq 0 ]; then
  echo "$MODEL_NAME" > "$MODEL_DIR/model.conf"
  echo "✅ Modelo baixado e configurado com sucesso!"
else
  echo "❌ Falha ao baixar o modelo. Verifique sua conexão!"
fi

# 📂 Organizing folder structure
echo -e "\n📁 Organizing files..."
mkdir -p "/sdcard/VOXNOTE/Manual Transcription"
mkdir -p "/sdcard/VOXNOTE/Subtitles"
mkdir -p "/sdcard/VOXNOTE/FinalizedSubtitles"
mkdir -p $HOME/VOXNOTE
chmod +x $HOME/VOXNOTE/scripts/transcrever2.sh
chmod +x $HOME/VOXNOTE/scripts/transcrever.sh
chmod +x $HOME/VOXNOTE/start.sh
chmod +x $HOME/VOXNOTE/build/bin/whisper-cli
chmod +x $HOME/VOXNOTE/scripts/legendar.sh

# 🔧 Create Termux Widget shortcut!
cp $HOME/VOXNOTE/start.sh  ~/.termux/widget/dynamic_shortcuts

# 📢 Final notification (if Termux-API is installed)
if command -v termux-notification &>/dev/null; then
 termux-notification\
  --title "VOXNOTE Installed." \
  --content "Script ready to use from Termux Widget!" \
  --priority high \
  --vibrate 200
else
     echo -e "\n✨ \033[1;32mAll set!\033[0m Now just open Termux Widget and tap on iniciar.sh"
fi
echo "*****Type ./start.sh in your terminal inside the VOXNOTE directory*****"
sleep 5

cd VOXNOTE


